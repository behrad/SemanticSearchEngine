#!/usr/local/bin/perl

$cvs_Id = '$Id: client-check-lookup-caching.pl,v 1.1 1999/12/08 20:36:47 elagache Exp $';
$cvs_Author = '$Author: elagache $';
$cvs_Name = '$Name: release-1-1 $';
$cvs_Revision = '$Revision: 1.1 $';



use CAIDA::NetGeoClient;

use strict;


## Main

$| = 1;				# print as soon as something to show


my $netgeo = new CAIDA::NetGeoClient();
$netgeo->useLocalCache(0);  # Disable cache to test real server lookups.


while (<>) {
    next if /^\s*$/;		# skip empty lines
    chop;

    my $entity = $_;

    my $result1 = $netgeo->getRecord($entity);

    my $start = time();
    my $result2 = $netgeo->getRecord($entity);
    my $end = time();

    my $delta = $end - $start;

    if (($delta > 1) || ($result1->{STATUS} ne $result2->{STATUS})) {
    print join("\t", $delta, $entity,
	       $result1->{STATUS},
	       $result2->{STATUS});
    print "\n";
    }
}
