#!/usr/local/bin/perl

## Simple script to lookup entries.
##
## $Id: lookup-entries.pl,v 1.1 1999/12/06 20:01:26 dmoore Exp $
##
## AUTHOR: David Moore, CAIDA
## <LICENSE>


use lib "/home/dmoore/workspace/donohoe/netgeo/";
use CAIDA::NetGeoClient;

use strict;

my $netgeo = new CAIDA::NetGeoClient();
#$netgeo->setNonblocking(1);

while (<>) {
    my $what = $_;
    chop $what;
    my $result = $netgeo->getRecord($what);
    
    while (my ($key, $value) = each %{$result}) {
	print "$key:\t$value\n";
    }
    print "\n";
}
