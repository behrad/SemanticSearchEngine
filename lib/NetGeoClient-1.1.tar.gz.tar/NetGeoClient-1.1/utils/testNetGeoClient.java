
/*****************************************************************************
* testNetGeoClient.java
* 
* $Id: testNetGeoClient.java,v 1.3 1999/11/14 22:06:37 donohoe Exp $
* 
* @author Jim Donohoe, CAIDA
* <LICENSE>
*****************************************************************************/

import java.util.*;

public class testNetGeoClient
{

/** 
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void main( String[] argv )
   {
      NetGeoClient netgeo = new NetGeoClient( "plot_AS_loc/1.2.3" );

      if( false )
      { 
         // 1882 has a record but no address
         testGetLatLong( netgeo, "AS1882" );

         // 2137 has an address but no zip
         testGetLatLong( netgeo, "AS2137" );

         // 1459 has no match in earlier lookups
         testGetLatLong( netgeo, "AS1459" );

         // 14003 hasn't been looked up yet (this will change)
         testGetLatLong( netgeo, "AS14003" );

         testGetRecord( netgeo, "AS2137" );
         testGetRecord( netgeo, "AS1459" );
      }

      if( false )
      { 
         testGetRecord( netgeo, "AS1" );
         testGetRecord( netgeo, "AS1" );
         testGetCountry( netgeo, " AS1 " );
         testGetLatLong( netgeo, "1" );

         testGetCountry( netgeo, "caida.org" );
         testGetCountry( netgeo, "Caida.ORG" );

         testGetLatLong( netgeo, "caida.org" );
         testGetLatLong( netgeo, "Caida.ORG" );

         testGetRecord( netgeo, "caida.org" );
         testGetRecord( netgeo, "Caida.ORG" );

         testGetCountry( netgeo, "caida.org" );

         testGetLatLong( netgeo, "caida.org" );
      }

      if( false )
      { 
         String[] targetArray = new String[3];
         targetArray[0] = "AS 1";
         targetArray[1] = "caida.org ";
         targetArray[2] = "192.172.226.15";

         printTargetArray( targetArray );

         testGetRecordArray( netgeo, targetArray );
         testGetCountryArray( netgeo, targetArray );
         testGetLatLongArray( netgeo, targetArray );
      }

      if( false )
      { 
         String[] targetArray = new String[3];
         targetArray[0] = "AS 1";
         targetArray[1] = "caida.org ";
         targetArray[2] = "192.172.226.15";

         printTargetArray( targetArray );

         boolean nonblocking = false;

         Hashtable[] hashArray = initializeHashArray( targetArray );
         testUpdateRecordArray( netgeo, hashArray, nonblocking );

         hashArray = initializeHashArray( targetArray );
         testUpdateCountryArray( netgeo, hashArray, nonblocking );

         hashArray = initializeHashArray( targetArray );
         testUpdateLatLongArray( netgeo, hashArray, nonblocking );
      }

      if( false )
      { 
         String[] targetArray = new String[20];
         int startNumber = 13820;
         for( int i = 0; i < targetArray.length; i++ )
         {
            targetArray[i] = "AS" + (startNumber + i);
         }

         printTargetArray( targetArray );

         boolean nonblocking = true;

         Hashtable[] hashArray = initializeHashArray( targetArray );
         testUpdateRecordArray( netgeo, hashArray, nonblocking );

         hashArray = initializeHashArray( targetArray );
         testUpdateCountryArray( netgeo, hashArray, nonblocking );

         hashArray = initializeHashArray( targetArray );
         testUpdateLatLongArray( netgeo, hashArray, nonblocking );
      }
      
      if( true )
      { 
         String[] targetArray = new String[20];
         int startNumber = 13820;
         for( int i = 0; i < targetArray.length; i++ )
         {
            targetArray[i] = "AS" + (startNumber + i);
         }

         printTargetArray( targetArray );

         boolean nonblocking = true;

         Hashtable[] hashArray = initializeHashArray( targetArray );
         testUpdateRecordArray( netgeo, hashArray, nonblocking );
      }

      if( false )
      { 
         String[] targetArray = new String[100];
	 
         for( int i = 0; i < targetArray.length; i++ )
         {
            targetArray[i] = "AS" + (2230 + i);
         }

         boolean nonblocking = true;

         System.out.println( "Testing getCountryArray" );
         netgeo.setNonblocking( nonblocking );
         Hashtable[] hashArray = netgeo.getCountryArray( targetArray );
         int count = printResultArray( hashArray );

         if( nonblocking )
         {
            System.out.println( "Testing updateCountryArray" );
            while( count < targetArray.length )
            {
               try
               {
                  Thread.sleep( 3000 );
               }
               catch( InterruptedException e )
               {
               }

               netgeo.setNonblocking( nonblocking );
               netgeo.updateCountryArray( hashArray );

               count = printResultArray( hashArray );
            }
         }
      }
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetRecord( NetGeoClient netgeo, String target )
   {
      System.out.println( "Testing getRecord( " + target + " )" );
      Hashtable result = netgeo.getRecord( target );

      Enumeration enum = result.keys();
      while( enum.hasMoreElements() )
      {
         String key = (String) enum.nextElement();
         String value = (String) result.get( key );
         System.out.println( key + ": " + value );
      }
      System.out.println();
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetCountry( NetGeoClient netgeo, String target )
   {
      System.out.println( "Testing getCountry( " + target + " )" );
      String country = netgeo.getCountry( target );

      System.out.println( target + ": " + country );
      System.out.println();
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetLatLong( NetGeoClient netgeo, String target )
   {
      System.out.println( "Testing getLatLong( " + target + " )" );
      Hashtable latLongHash = netgeo.getLatLong( target );

      if( latLongHash.get("HTTP_ERROR") != null )
      {
         System.out.println( latLongHash.get("HTTP_ERROR") );
         return;
      }

      System.out.println( target + ": " + "(" + latLongHash.get("LAT") + 
                          "," + latLongHash.get("LONG") + ")" );
      System.out.println( "As floats: " + 
                          "(" + NetGeoClient.getLat( latLongHash ) + "," +
                          NetGeoClient.getLong( latLongHash )  + ")" );
      System.out.println( "STATUS: " + latLongHash.get("STATUS") );

      System.out.println();
   }



/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetRecordArray( NetGeoClient netgeo, 
                                          String[] targetArray )
   {
      System.out.println( "Testing getRecordArray( targetArray )" );
      Hashtable[] hashArray = netgeo.getRecordArray( targetArray );

      printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetCountryArray( NetGeoClient netgeo, 
                                           String[] targetArray )
   {
      System.out.println( "Testing getCountryArray( targetArray )" );
      Hashtable[] hashArray = netgeo.getCountryArray( targetArray );

      printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testGetLatLongArray( NetGeoClient netgeo,
                                           String[] targetArray)
   {
      System.out.println( "Testing getLatLongArray( targetArray )" );
      Hashtable[] hashArray = netgeo.getLatLongArray( targetArray );

      printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testUpdateRecordArray( NetGeoClient netgeo, 
                                             Hashtable[] hashArray,
                                             boolean nonblocking )
   {
      System.out.println( "\n=============================================" );
      System.out.println( "Testing updateRecordArray( hashArray )" );
      netgeo.setNonblocking( nonblocking );
      String result = netgeo.updateRecordArray( hashArray );
      if( result.equals( NetGeoClient.NETGEO_LIMIT_EXCEEDED ) )
      {
         System.out.println( result );
      }
      
      if( nonblocking )
      {
         // Count the number of successful lookups in the array.
         int count = countCompletedLookups( hashArray );
         while( count < hashArray.length )
         {
            result = netgeo.updateRecordArray( hashArray );
            if( result.equals( NetGeoClient.NETGEO_LIMIT_EXCEEDED ) )
            {
               System.out.println( result );
            }
            count = countCompletedLookups( hashArray );
         }
      }

      // printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testUpdateCountryArray( NetGeoClient netgeo, 
                                              Hashtable[] hashArray,
                                              boolean nonblocking )
   {
      System.out.println( "Testing updateCountryArray( hashArray )" );
      netgeo.setNonblocking( nonblocking );
      netgeo.updateCountryArray( hashArray );

      printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void testUpdateLatLongArray( NetGeoClient netgeo,
                                              Hashtable[] hashArray,
                                              boolean nonblocking )
   {
      System.out.println( "Testing updateLatLongArray( hashArray )" );
      netgeo.setNonblocking( nonblocking );
      netgeo.updateLatLongArray( hashArray );

      printResultArray( hashArray );
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static int printResultArray( Hashtable[] hashArray )
   {
      if( hashArray == null )
      {
         System.out.println( "Result array == null" );	
         return 0;
      }
      else if( hashArray.length == 0 )
      {
         System.out.println( "Result array length == 0" );
         return 0;
      }	  

      int count = 0;
      for( int i = 0; i < hashArray.length; i++ )
      {
         Hashtable result = hashArray[i];
         String status = (String) result.get( "STATUS" );
         if( status == null ||
             ! status.equals( NetGeoClient.LOOKUP_IN_PROGRESS ) )
         {
            count += 1;
            String target = (String) result.get( "TARGET" );
            System.out.println( "TARGET: " + target );

            Enumeration enum = result.keys();
            while( enum.hasMoreElements() )
            {
               String key = (String) enum.nextElement();
               String value = (String) result.get( key );
               if( ! key.equals( "TARGET" ) )
               {
                  System.out.println( key + ": " + value );
               }
            }
            System.out.println();
         }
      }
      System.out.println( "Lookups in progress: " + (hashArray.length-count) );
      System.out.println( "---------------------------------------------\n" );

      return count;
   }



/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static int countCompletedLookups( Hashtable[] hashArray )
   {
      if( hashArray == null )
      {
         System.out.println( "Result array == null" );	
         return 0;
      }
      else if( hashArray.length == 0 )
      {
         System.out.println( "Result array length == 0" );
         return 0;
      }	  

      int count = 0;
      for( int i = 0; i < hashArray.length; i++ )
      {
         Hashtable result = hashArray[i];
         String status = (String) result.get( "STATUS" );
         if( status != null && ( status.equals( NetGeoClient.OK ) ||
                                 status.equals( NetGeoClient.NO_MATCH ) ||
                                 status.equals( NetGeoClient.NO_COUNTRY ) ||
                                 status.equals( NetGeoClient.UNKNOWN ) ) )
         {
            count += 1;
         }
      }
      System.out.println( count + " out of " + hashArray.length +
                          " lookups completed." );
      
      return count;
   }   


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static void printTargetArray( String[] targetArray )
   {
      if( targetArray != null && targetArray.length > 0 )
      {
         System.out.print( "Target = [ \"" + targetArray[0] + "\"" );
         for( int i = 1; i < targetArray.length; i++ )
         {
            System.out.print( ", \"" + targetArray[i] + "\"" );
         }
         System.out.println( " ]" );
      }
   }


/**
  * Description : 
  * 
  * @param 
  * @return void  
  * @author Jim Donohoe
  */
   public static Hashtable[] initializeHashArray( String[] targetArray )
   {
      Hashtable[] hashArray = new Hashtable[0];
      if( targetArray != null )
      {
         hashArray = new Hashtable[ targetArray.length ];
         for( int i = 0; i < targetArray.length; i++ )
         {
            hashArray[i] = new Hashtable();
            hashArray[i].put( "TARGET", targetArray[i] );
         }
      }
      return hashArray;
   }

}
